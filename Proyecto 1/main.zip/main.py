import random

def montysGame(changeDoor, showLog):
    doorsList = [1, 2, 3]
    carDoor = random.randint(1, 3)
    doorSelected = random.randint(1, 3)
    doorsList.remove(doorSelected)

    if (carDoor == doorSelected):
        montysDoor = random.randint(0, 1)
        doorsList.pop(montysDoor)
    else:
        montysDoor = doorsList.pop(1 if doorsList[0] == carDoor else 0)

    previousDoor = doorSelected 
    if (changeDoor):
        doorSelected = doorsList[0]
    if (showLog):
        print("Puerta elegida: " + str(previousDoor))
        print("Puerta donde esta el auto: " + str(carDoor))
        print("Puerta que abrio Monty:" + str(montysDoor))
        print("Se cambio la puerta" if changeDoor else "No cambio la puerta")
        print("Jugador gano el auto" if carDoor == doorSelected else "Perdio el auto")
    return carDoor == doorSelected

def montysGame2(changeDoor, showLog):
    doorsList = [1, 2, 3]
    carDoor = random.randint(1, 3)
    doorSelected = random.randint(1, 3)
    doorsList.remove(doorSelected)

    if (carDoor == doorSelected):
        montysDoor = random.randint(0, 1)
    else:
        montysDoor = 0 if doorsList[0] == carDoor else 1

    previousDoor = doorSelected
    if (changeDoor):
        doorSelected = doorsList[montysDoor]
    if (showLog):
        print("Puerta elegida: " + str(previousDoor))
        print("Puerta donde esta el auto: " + str(carDoor))
        print("Se cambio la puerta" if changeDoor else "No cambio la puerta")
        print("Jugador gano el auto" if carDoor == doorSelected else "Perdio el auto")

    return carDoor == doorSelected

def montysGameAnalyzer(changeDoor, maxRange):
    victories = 0
    for i in range(0, maxRange):
        if(montysGame2(changeDoor, False)):
            victories += 1
    return victories

maxRange = 30000
victories = montysGameAnalyzer(True, maxRange)
print("El jugador cambiando la puerta gano " + str(victories) + "(" + str(victories * (100/maxRange)) + "%)" + " veces de " + str(maxRange))

victories = montysGameAnalyzer(False, maxRange)
print("El jugador sin cambiar la puerta gano " + str(victories) + "(" + str(victories * (100/maxRange)) + "%)" + " veces de " + str(maxRange))